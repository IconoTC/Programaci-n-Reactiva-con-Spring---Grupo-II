package com.softtek.persistence;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

import com.softtek.models.Alumno;

// No necesita anotacion al ser un Repository de Spring
public interface AlumnosDAO extends R2dbcRepository<Alumno, Integer>{
}
	
	
	