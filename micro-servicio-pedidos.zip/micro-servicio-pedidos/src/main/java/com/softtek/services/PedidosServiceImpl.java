package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Pedido;
import com.softtek.models.Producto;

import reactor.core.publisher.Mono;

@Service
public class PedidosServiceImpl implements IPedidosService{
	
	@Autowired
	private WebClient webClient;

	@Override
	public Mono<Pedido> crearPedido(int id, int cantidad) {
		// Solucion 1
		// Obtener Mono<Producto> y el Mono<Integer> y combinarlos con flatMap
		Mono<Producto> monoProducto = webClient
				.get().uri("/buscar/{id}", id)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Producto.class);
		
		Mono<Integer> monoCantidad = Mono.just(cantidad);
		
		Mono<Pedido> monoPedido = monoProducto.flatMap(prod -> monoCantidad.map(c -> new Pedido(prod, c)));
		//return monoPedido;
		
		
		// Solucion 2
		
		return webClient
				.get().uri("/buscar/{id}", id)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Producto.class)
				.flatMap(prod -> Mono.just(new Pedido(prod, cantidad)));
	}

}
