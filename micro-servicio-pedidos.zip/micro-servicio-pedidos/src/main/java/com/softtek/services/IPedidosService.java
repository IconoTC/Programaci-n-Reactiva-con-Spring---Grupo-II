package com.softtek.services;

import com.softtek.models.Pedido;

import reactor.core.publisher.Mono;

public interface IPedidosService {
	
	Mono<Pedido> crearPedido(int id, int cantidad);

}
