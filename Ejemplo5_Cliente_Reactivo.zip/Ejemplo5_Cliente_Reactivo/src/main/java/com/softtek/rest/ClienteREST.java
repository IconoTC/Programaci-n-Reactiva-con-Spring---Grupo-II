package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Alumno;
import com.softtek.services.IClienteAlumnos;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class ClienteREST {
	
	@Autowired
	private IClienteAlumnos service;
	
	// http://localhost:8082/todos
	@GetMapping("/todos")
	public Flux<Alumno> todos(){
		return service.consultarTodos();
	}
	
	// http://localhost:8082/buscar/3
	@GetMapping("/buscar/{id}")
	public Mono<Alumno> buscar(@PathVariable int id){
		return service.buscarAlumno(id);
	}
	
	// http://localhost:8082/crear
	@PostMapping("/crear")
	public Mono<Alumno> crear(@RequestBody Alumno alumno){
		return service.crearNuevo(alumno);
	}
	
	// http://localhost:8082/modificar
	@PutMapping("/modificar")
	public Mono<Alumno> modificar(@RequestBody Alumno alumno){
		return service.modificarAlumno(alumno);
	}
	
	// http://localhost:8082/borrar/5
	@DeleteMapping("/borrar/{id}")
	public Mono<Void> eliminar(@PathVariable int id){
		return service.eliminarAlumno(id);
	}
}









