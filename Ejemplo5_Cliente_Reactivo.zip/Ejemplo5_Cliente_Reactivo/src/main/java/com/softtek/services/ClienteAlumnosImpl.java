package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ClienteAlumnosImpl implements IClienteAlumnos{
	
	@Autowired
	private WebClient webClient;

	@Override
	public Flux<Alumno> consultarTodos() {
		return webClient.get().uri("/alumnos")
				.retrieve()
				.bodyToFlux(Alumno.class);
	}

	@Override
	public Mono<Alumno> buscarAlumno(int id) {
		return webClient.get().uri("/alumnos/{id}", id)
				.retrieve()
				.bodyToMono(Alumno.class);
	}

	@Override
	public Mono<Alumno> crearNuevo(Alumno alumno) {
		return webClient.post().uri("/alumnos")
				.body(BodyInserters.fromValue(alumno))
				.retrieve()
				.bodyToMono(Alumno.class);
	}

	@Override
	public Mono<Void> eliminarAlumno(int id) {
		return webClient.delete().uri("/alumnos/{id}", id)
				.exchangeToMono(response -> {
			         if (response.statusCode().equals(HttpStatus.OK)) {
			             return response.bodyToMono(Alumno.class);
			         }
			         else {
			             return response.createException().flatMap(Mono::error);
			         }
			     })
				.then();
	}

	@Override
	public Mono<Alumno> modificarAlumno(Alumno alumno) {
		return webClient.put().uri("/alumnos")
				.body(BodyInserters.fromValue(alumno))
				.retrieve()
				.bodyToMono(Alumno.class);
	}

}
