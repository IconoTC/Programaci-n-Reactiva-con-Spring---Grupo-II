package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class Ejemplo5ClienteReactivoApplication {
	
	// En Spring como cliente de un servicio REST podemos utilizar:
	//     - RestTemplate,  pertenece a Spring MVC
	//     - Feign,  pertenece a Spring Cloud
	// Ninguno de los dos es reactivo.
	
	// En programacion reactiva, utilizamos WebClient que pertenece a Spring WebFlux
	@Bean
	public WebClient webClient() {
		return WebClient.create("http://localhost:8081/api");
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5ClienteReactivoApplication.class, args);
	}

}
