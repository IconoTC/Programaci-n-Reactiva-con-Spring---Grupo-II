package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class MicroServicioCarritoApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate template;
	
	@Bean
	public WebClient webClient() {
		return WebClient.create("http://localhost:8087");
	}

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Eliminar la coleccion carritos
		template.dropCollection("carritos").subscribe();
		
	}

}
