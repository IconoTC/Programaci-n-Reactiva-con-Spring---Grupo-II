package com.softtek.services;

import com.softtek.models.Carrito;

import reactor.core.publisher.Mono;

public interface ICarritosService {
	
	Mono<Carrito> crear(String usuario);
	
	Mono<Carrito> consultar(String usuario);
	
	Mono<Carrito> agregarPedido(int id, int cantidad, String usuario);
	
	Mono<Carrito> eliminarPedido(int id, String usuario);

}
