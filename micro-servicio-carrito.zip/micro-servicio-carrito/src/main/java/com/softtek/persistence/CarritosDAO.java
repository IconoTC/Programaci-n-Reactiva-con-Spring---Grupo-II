package com.softtek.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.softtek.models.Carrito;

import reactor.core.publisher.Mono;

public interface CarritosDAO extends ReactiveMongoRepository<Carrito, String>{
	
	Mono<Carrito> findByUsuario(String usuario);

}
