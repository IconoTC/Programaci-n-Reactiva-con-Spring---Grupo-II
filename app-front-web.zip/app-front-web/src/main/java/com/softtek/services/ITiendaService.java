package com.softtek.services;

import com.softtek.models.Carrito;
import com.softtek.models.Producto;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ITiendaService {
	
	Flux<Producto> obtenerTodos();
	
	Mono<Carrito> crear(String usuario);
	
	Mono<Carrito> consultar(String usuario);
	
	Mono<Carrito> agregarPedido(int id, int cantidad, String usuario);
	
	Mono<Carrito> eliminarPedido(int id, String usuario);

}
