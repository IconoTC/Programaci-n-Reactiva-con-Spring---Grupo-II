package com.softtek.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.softtek.services.ITiendaService;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private ITiendaService service;
	
	@PostMapping
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String usuario = request.getParameter("user");
		Cookie cookie = new Cookie("nombreUsuario", usuario);
		response.addCookie(cookie);
		
		// Crear el carrito al usuario
		service.crear(usuario).block();
		
		return "index";
		
	}

}
