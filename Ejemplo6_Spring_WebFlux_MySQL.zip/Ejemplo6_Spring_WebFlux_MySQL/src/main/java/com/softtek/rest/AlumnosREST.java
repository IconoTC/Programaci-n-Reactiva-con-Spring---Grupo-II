package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Alumno;
import com.softtek.services.IAlumnosService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")   // http://localhost:8081/api
public class AlumnosREST {
	
	@Autowired
	private IAlumnosService service;
	
	// http://localhost:8081/api/alumnos
	@GetMapping("/alumnos")
	public Flux<Alumno> todos(){
		return service.consultarTodos();
	}
	
	// http://localhost:8081/api/alumnos/3
	@GetMapping("/alumnos/{id}")
	public Mono<ResponseEntity<Alumno>> consultarAlumno(@PathVariable(name = "id") Long id){
		return service.buscarAlumno(id)
				.map(alum -> ResponseEntity.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(alum))
				.defaultIfEmpty(ResponseEntity.notFound()
				.build());
	}
	
	// http://localhost:8081/api/alumnos
	@PostMapping("/alumnos")
	public Mono<Alumno> insertarAlumno(@RequestBody Alumno alumno){
		return service.crearNuevo(alumno);
	}
	
	// http://localhost:8081/api/alumnos/5
	@DeleteMapping("/alumnos/{id}")
	public Mono<Void> eliminarAlumno(@PathVariable Long id){
		return service.eliminarAlumno(id);
	}
	
	// http://localhost:8081/api/alumnos
	@PutMapping("/alumnos")
	public Mono<Alumno> modificar(@RequestBody Alumno alumno){
		return service.modificarAlumno(alumno);
	}

}








