package com.softtek.persistence;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;

// No necesita anotacion al ser un Repository de Spring
public interface AlumnosDAO extends R2dbcRepository<Alumno, Long>{
	
	@Query("select * from alumnos")
	public Flux<Alumno> miQuery();
}
	
	
	