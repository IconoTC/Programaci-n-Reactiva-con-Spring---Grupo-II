package com.softtek.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.softtek.models.Alumno;

import reactor.core.publisher.Mono;

// Cualquier Repository de Spring es un componente manejado de Spring y
// no necesita anotacion, se puede inyectar sin problema
public interface AlumnosDAO extends ReactiveMongoRepository<Alumno, String>{
	
	// Ademas de los metodos heredados de Repository podemos crear metodos
	// personalizados utilizando keywords
	// https://docs.spring.io/spring-data/mongodb/reference/repositories/query-keywords-reference.html
	
	public Mono<Alumno> findByNombre(String nombre);
	
}	
	
	