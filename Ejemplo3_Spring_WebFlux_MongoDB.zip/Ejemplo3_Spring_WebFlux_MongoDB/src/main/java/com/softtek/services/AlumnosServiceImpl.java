package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnosServiceImpl implements IAlumnosService{
	
	@Autowired
	private AlumnosDAO dao;

	@Override
	public Flux<Alumno> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Mono<Alumno> buscarAlumno(String id) {
		return dao.findById(id);
	}
	
	@Override
	public Mono<Alumno> buscarAlumnoPorNombre(String nombre) {
		return dao.findByNombre(nombre);
	}

	@Override
	public Mono<Alumno> crearNuevo(Alumno alumno) {
		return dao.save(alumno);
	}

	@Override
	public Mono<Void> eliminarAlumno(String id) {
		return dao.deleteById(id);
	}

	@Override
	public Mono<Alumno> modificarAlumno(Alumno alumno) {
		return dao.save(alumno);
	}

	
}
