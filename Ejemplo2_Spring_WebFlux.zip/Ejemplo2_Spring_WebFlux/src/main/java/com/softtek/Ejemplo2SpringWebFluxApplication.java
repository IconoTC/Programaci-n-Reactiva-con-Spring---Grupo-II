package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

}
