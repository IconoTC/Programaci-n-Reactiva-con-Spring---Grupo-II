package com.softtek.persistence;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class AlumnosDAO {
	
	// Crear una lista con 4 alumnos
	List<Alumno> lista = new LinkedList<>(Arrays.asList(
			new Alumno(1, "Juan", "Lopez", 6.5),
			new Alumno(2, "Pedro", "Rodriguez", 3.5),
			new Alumno(3, "Maria", "Sanchez", 9.3),
			new Alumno(4, "Laura", "Fernandez", 7.8)));
	
	
	public Flux<Alumno> todos(){
		return Flux.fromIterable(lista);
	}
	
	public Mono<Alumno> buscar(int id){
		// Solucion 1
//		return Mono.just(
//				lista.stream()
//					.filter(alum -> alum.getId() == id)
//					.findAny()
//					.orElse(new Alumno())
//				);
		
		// Solucion 2
		return todos().filter(alum -> alum.getId() == id).singleOrEmpty();
	}
	
	public Mono<Alumno> crearNuevo(Alumno nuevo){
		lista.add(nuevo);
		return Mono.just(nuevo);
		
		// return buscar(nuevo.getId());
	}
	
	public Mono<Void> eliminar(int id){
		lista.removeIf(alum -> alum.getId() == id);
		return Mono.empty();
	}
	
	public Mono<Alumno> modificar(Alumno alumno){
		// Solucion 1
//		int indice = -1;
//		
//		for (int i = 0; i < lista.size(); i++) {
//			Alumno alum = lista.get(i);
//			if (alum.getId() == alumno.getId()) {
//				indice = i;
//				break;
//			}
//		}
//		
//		return Mono.just(lista.set(indice, alumno));
		
		// Solucion 2
//		lista.removeIf(alum -> alum.getId() == alumno.getId());
//		lista.add(alumno);
//		return Mono.just(alumno);
		
		// Solucion 3
//		lista.stream().forEach(p -> { 
//			if(p.getId() == alumno.getId()) { 
//				p.setApellido(alumno.getApellido());
//				p.setNombre(alumno.getNombre());
//				p.setNota(alumno.getNota()); 
//			} 
//			}); 
//			return buscar(alumno.getId());
			
		// Solucion 4
			return todos() 
					.index() 
					.filter(tuple->tuple.getT2().getId() == alumno.getId()) 
					.take(1) 
					.single() 
					.flatMap(tuple->{ 
						Alumno alumnoMod = tuple.getT2();
						int indice = tuple.getT1().intValue(); // Obtiene el índice del elemento 
						alumnoMod.setApellido(alumno.getApellido()); 
						alumnoMod.setNombre(alumno.getNombre()); 
						alumnoMod.setNota(alumno.getNota()); 
						lista.set(indice, alumnoMod); 
					// Puedes hacer uso del índice aquí 
					return Mono.just(alumnoMod); 
					});
	}

}
