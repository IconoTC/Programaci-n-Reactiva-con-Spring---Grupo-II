package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Producto;
import com.softtek.persistence.ProductosDAO;
import com.softtek.rest.HandlerProductos;

import reactor.core.publisher.Flux;

@SpringBootApplication
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;
	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerProductos handler){
		return RouterFunctions
				// http://localhost:8086/listar
				.route(RequestPredicates.GET("/listar"), handler::todos)
				// http://localhost:8086/buscar/2
				.andRoute(RequestPredicates.GET("/buscar/{id}"), handler::buscar);
	}

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Flux.just(
				new Producto("Pantalla", 129.95),
				new Producto("Raton", 27.50),
				new Producto("Teclado", 52.75))
					.flatMap(prod -> dao.save(prod))
					.subscribe(prod -> System.out.println(prod));
		
	}

}
