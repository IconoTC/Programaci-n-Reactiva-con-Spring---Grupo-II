package com.softtek.persistence;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

import com.softtek.models.Producto;

public interface ProductosDAO extends R2dbcRepository<Producto, Integer>{

}
