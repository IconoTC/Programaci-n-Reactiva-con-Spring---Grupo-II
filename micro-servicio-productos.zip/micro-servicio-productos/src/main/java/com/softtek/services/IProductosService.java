package com.softtek.services;

import com.softtek.models.Producto;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IProductosService {
	
	Flux<Producto> listar();
	
	Mono<Producto> buscar(int id);

}
